Qt 앱을 구현한 코드

페스트가드 프로젝트에서 사용자가 간편하게 터틀봇을 조작하고 상태를 관리 할 수 있게 해주는 앱.

리눅스 OS 환경에서 구동이 되며, Qt Creator 실행 후 AiotCient_tab5 파일 내에 AiotClient.pro파일을 오픈하여 빌드하면 됨.
