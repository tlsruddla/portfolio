mkdir build
cd build
cmake ..