roslaunch turtlebot3_navigation turtlebot3_navigation.launch map_file:=/workspace/finalmap.yaml
